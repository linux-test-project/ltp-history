/*
 * v4l-test: Test environment for Video For Linux Two API
 *
 * 21 Dec 2008  0.1  First release
 *
 * Written by M�rton N�meth <nm127@freemail.hu>
 * Released under GPL
 */

void test_VIDIOC_CROPCAP(void);
void test_VIDIOC_CROPCAP_enum_INPUT(void);
void test_VIDIOC_CROPCAP_NULL(void);
