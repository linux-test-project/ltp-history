/*
 * v4l-test: Test environment for Video For Linux Two API
 *
 * 30 Jan 2009  0.1  First release
 *
 * Written by M�rton N�meth <nm127@freemail.hu>
 * Released under GPL
 */

void test_VIDIOC_QUERYSTD(void);
void test_VIDIOC_QUERYSTD_NULL(void);
