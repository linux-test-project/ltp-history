/*
 * v4l-test: Test environment for Video For Linux Two API
 *
 * 18 Dec 2008  0.1  First release
 *
 * Written by M�rton N�meth <nm127@freemail.hu>
 * Released under GPL
 */

void test_invalid_ioctl_1(void);
void test_invalid_ioctl_2(void);
void test_invalid_ioctl_3(void);
void test_invalid_ioctl_4(void);

