
struct sysdev_attribute {};
