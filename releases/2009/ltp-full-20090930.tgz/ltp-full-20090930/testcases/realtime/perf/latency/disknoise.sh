#!/bin/bash

while :
do
	find / -type f -print > /dev/null 2>&1
done
